package projetJava;

/**
 * Classe Jeu : cette classe consiste essentiellement à gérer le déroulement du
 * jeu
 * 
 * @author BOUTON Nicolas, DEDARALLY Taariq et TRINH Gia Tâm
 * @version mai 2019
 */
public class Jeu {

	/** Undo permet la gestion de la pile */
	private Undo undo;

	/** Plateau : le plateau du jeu */
	private Plateau plateau;

	/** IO permet la gestion des entrées (clavier) sortie (output terminal) */
	private IO io;

	/** Joueur permet de décider quel joueur joue */
	private Joueur joueur;

	/** Itérateur du nombre de tours */
	private int tours;

	/**
	 * Constructeur du jeu : initialisation de piles vide, déclaration du tableau
	 * vide et déclaration de joueur
	 */
	public Jeu() {
		this.undo = new Undo();
		this.plateau = new Plateau();
		this.io = new IO(this.undo);
		this.joueur = new Joueur();

		this.tours = 0;

		this.plateau.afficher(this.tours);
	}

	/**
	 * Gestion du Jeu : lancer les différentes méthode permettant de dérouler
	 * l'application jusqu'à echec et mat
	 */
	public void jouer() {
		boolean noQuit = true;

		while (noQuit && this.isMat(tours % 2)) {
			if (this.tours % 2 == 0) {
				if (this.joueur.getJ1().equals("H")) {
					if (this.plateau.isEchec(tours % 2)) {
						System.out.println("Echec !");
					}
					noQuit = this.io.entryPiece(this.plateau, this.tours % 2, this.tours);
				} else {
					if (!this.ia(this.tours % 2)) {
						if (this.plateau.isEchec(tours % 2)) {
							System.out.println("Echec !");
						}
						noQuit = false;
					}
				}
			} else {
				if (this.joueur.getJ2().equals("H")) {
					if (this.plateau.isEchec(tours % 2)) {
						System.out.println("Echec !");
					}
					noQuit = this.io.entryPiece(this.plateau, this.tours % 2, this.tours);
				} else {

					if (!this.ia(this.tours % 2)) {
						if (this.plateau.isEchec(tours % 2)) {
							System.out.println("Echec !");
						}
						noQuit = false;
					}
				}
			}

			this.tours++;
			if (noQuit) {
				this.plateau.afficher(this.tours);
			}
		}
	}

	/**
	 * Situation d'échec et mat
	 * 
	 * @param couleur la couleur du roi
	 * @return vrai si le roi est en situation d'échec et mat
	 */
	public boolean isMat(int couleur) {
		final Point point_init = new Point(this.plateau.findKing(couleur).getX(),
				this.plateau.findKing(couleur).getY());
		return this.checkisMatHV(point_init, couleur) || this.checkisMatDiagonal(point_init, couleur);
	}

	/**
	 * Verifie si le roi est en situation d'échec et mat sur l'abscisse et
	 * l'ordonnée
	 * 
	 * @param point_init la position du roi
	 * @param couleur    la couleur du roi
	 * @return faux si le roi n'est pas situation d'échec et mat en abscisse et
	 *         ordonnée et vrai sinon
	 */
	public boolean checkisMatHV(final Point point_init, int couleur) {
		Point point = new Point(point_init.getX(), point_init.getY());
		if (this.plateau.checkMove_isEchec(point, couleur)) {
			point.setX(point_init.getX() + 1);
			point.setY(point_init.getY());
			if (this.plateau.checkMove_isEchec(point, couleur)) {
				point.setX(point_init.getX());
				point.setY(point_init.getY() + 1);
				if (this.plateau.checkMove_isEchec(point, couleur)) {
					point.setX(point_init.getX() - 1);
					point.setY(point_init.getY());
					if (this.plateau.checkMove_isEchec(point, couleur)) {
						point.setX(point_init.getX());
						point.setY(point_init.getY() - 1);
						if (this.plateau.checkMove_isEchec(point, couleur)) {
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	/**
	 * Verifie si le roi est situation d'échec et mat sur les diagonales
	 * 
	 * @param point_init la position du roi
	 * @param couleur    la couleur du roi
	 * @return vrai si le roi n'est pas situation d'échec et mat en diagonale et
	 *         faux sinon
	 */
	public boolean checkisMatDiagonal(final Point point_init, int couleur) {
		Point point = new Point(point_init.getX() + 1, point_init.getY() + 1);
		if (this.plateau.checkMove_isEchec(point, couleur)) {
			point.setX(point_init.getX() - 1);
			point.setY(point_init.getY() + 1);
			if (this.plateau.checkMove_isEchec(point, couleur)) {
				point.setX(point_init.getX() + 1);
				point.setY(point_init.getY() - 1);
				if (this.plateau.checkMove_isEchec(point, couleur)) {
					point.setX(point_init.getX() - 1);
					point.setY(point_init.getY() - 1);
					if (this.plateau.checkMove_isEchec(point, couleur)) {
						return false;
					}
				}
			}
		}
		return true;
	}

	/**
	 * Algorithme de l'ordinateur
	 * 
	 * @param couleur la couleur de la pièce
	 * @return vrai si c'est bon et faux sinon
	 */
	public boolean ia(int couleur) {

		int x_depart;
		int y_depart;
		int x_cible;
		int y_cible;

		Piece piece_depart;
		Piece piece_cible;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				x_depart = i;
				y_depart = j;

				for (int k = 0; k < 8; k++) {
					for (int l = 0; l < 8; l++) {
						x_cible = k;
						y_cible = l;

						if (this.plateau.getPiece(x_depart, y_depart) != null
								&& this.plateau.getPiece(x_depart, y_depart).getCoul() == couleur) {
							piece_depart = plateau.getPiece(x_depart, y_depart);
							piece_cible = plateau.getPiece(x_cible, y_cible);

							if (plateau.inMap(x_depart, y_depart, x_cible, y_cible)
									&& plateau.movePiece(x_depart, y_depart, x_cible, y_cible)) {
								Point point_depart = new Point(x_depart, y_depart);
								Point point_cible = new Point(x_cible, y_cible);
								this.io.empile(point_depart, point_cible, piece_depart, piece_cible);
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
}
