package projetJava;

/**
 * Classe Tour : gestion de la pièce tour
 * 
 * @author BOUTON Nicolas
 */
public class Tour extends Piece {

	private final String nom = "T";

	/**
	 * Constructeur de la tour
	 * 
	 * @param couleur la couleur de la tour
	 */
	public Tour(int couleur) {
		super(couleur);
	}

	/**
	 * Retourne la chaine de caractères composé du nom et de la couleur de la tour
	 * 
	 * @return le nom et la couleur du tour
	 */
	@Override
	public String toString() {
		return this.nom + this.getCoul();
	}

	/**
	 * Déplacement du fou
	 * 
	 * @return vrai si le déplacement est valide ou faux sinon
	 */
	@Override
	public boolean movePiece(int depX, int depY, int finX, int finY) {
		if ((depX == finX) || (depY == finY)) {
			return true;
		}

		return false;
	}
}