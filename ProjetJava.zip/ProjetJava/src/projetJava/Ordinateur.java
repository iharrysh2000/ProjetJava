package projetJava;

import java.util.Random;

/**
 * Classe Ordinateur représentant un joueur ordinateur
 */
public class Ordinateur {

	private Joueur ordi;
	private int couleur;

	public Ordinateur(Joueur ordi, int couleur) {
		this.ordi = ordi;
		this.couleur = couleur;
	}

	/**
	 * Generation de nombres aléatoires
	 * 
	 * @param min le minimum
	 * @param max le maximum
	 * @return un nombre aléatoire entre le minimum et le maximum
	 */
	private static int getRandomNumberInRange(int min, int max) {

		Random r = new Random();
		return r.ints(min, (max + 1)).limit(1).findFirst().getAsInt();

	}

	/**
	 * Déplacement aléatoire d'une pièce de l'ordinateur
	 * 
	 * @param plateau le plateau de jeu
	 * @return vrai si c'est bon et faux sinon
	 */
	/*public boolean déplacement(Plateau plateau) {
		// 1ere action : Il choisit au pif un jeton sur la carte
		int debX = getRandomNumberInRange(0, 7);
		int debY = getRandomNumberInRange(0, 7);
		// 2eme action : Il regarde si c'est un jeton à lui. Sinon, on recommence.
		if (this.couleur == plateau[debX][debY].piece.couleur) {
			// 3eme action : Il vérifie qu'il y a un déplacement possible
			int finX = getRandomNumberInRange(0, 7); // on definit l'abscisse d'arrivée
			int finY = getRandomNumberInRange(0, 7); // on definiti
			if (movePiece(debX, debY, finX, finY) == true) { // Si un tel deplacement existe, il le fait
				// 4ème action : Il effectue un déplacement
				// ???????
				// Retourner vrai pour procéder à la suite du programme
				return true;
			}

		} else { // Si le jeton choisi ne lui appartient pas, on recommence dans le programme
			return false;
		}

	}*/
}
