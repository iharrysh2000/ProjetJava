package projetJava;

/**
 * Classe Point : gestion des couples de points pour le tableau
 * 
 * @author DEDARALLY Taariq
 * 
 */
public class Point {

	/** entier x représentant les abscisses */
	private int x;

	/** entier y représentant les ordonnées */
	private int y;

	/**
	 * Constructeur du point
	 * 
	 * @param x l'abscisse
	 * @param y l'ordonnée
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Getteur du retour de l'ordonnée du point
	 * 
	 * @return un entier
	 */
	public int getY() {
		return this.y;
	}

	/**
	 * Getteur du retour de l'abscisse du point
	 * 
	 * @return un entier
	 */
	public int getX() {
		return this.x;
	}

	/**
	 * Setteur de l'abscisse
	 * 
	 * @param x l'absicce
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * Setteur de l'ordonnée
	 * 
	 * @param y l'ordonnée
	 */
	public void setY(int y) {
		this.y = y;
	}
}