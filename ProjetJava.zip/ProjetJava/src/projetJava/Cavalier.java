package projetJava;

/**
 * Classe Cavalier : gestion de la pièce cavalier
 * 
 * @author BOUTON Nicolas
 */
public class Cavalier extends Piece {

	private final String nom = "C";

	/**
	 * Constructeur du cavalier
	 * 
	 * @param couleur la couleur du cavalier
	 */
	public Cavalier(int couleur) {
		super(couleur);
	}

	/**
	 * Renvoie la chaine de caractères composée du nom et de la couleur du cavalier
	 * 
	 * @return le nom et la couleur du cavalier
	 */
	@Override
	public String toString() {
		return this.nom + this.getCoul();
	}

	/**
	 * Déplacement du cavalier
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le déplacement est valide ou faux sinon
	 */
	@Override
	public boolean movePiece(int depX, int depY, int finX, int finY) {
		int dx = finX - depX;
		int dy = finY - depY;
		int distance = (dx >= 0 ? dx : -dx) + (dy >= 0 ? dy : -dy);

		if (distance == 3 && dx != 0 && dy != 0) {
			return true;
		}

		return false;
	}
}