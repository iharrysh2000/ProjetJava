package projetJava;

/**
 * Classe Pion : gestion de la pièce pion
 * 
 * @author BOUTON Nicolas
 *
 */
public class Pion extends Piece {

	private final String nom = "P";

	/**
	 * Constructeur du pion
	 * 
	 * @param couleur la couleur du pion
	 */
	public Pion(int couleur) {
		super(couleur);
	}

	/**
	 * Retourne la chaine de caractères composé du nom et de la couleur du pion
	 * 
	 * @return le nom et la couleur du pion
	 */
	@Override
	public String toString() {
		return this.nom + this.getCoul();
	}

	/**
	 * Déplacement du pion
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le déplacement est valide ou faux sinon
	 */
	@Override
	public boolean movePiece(int depX, int depY, int finX, int finY) {
		int dx = finX - depX;
		int dy = finY - depY;

		if (this.getCoul() == 0) {
			if (dx == 0) {
				if (this.getMove() && dy == 1) {
					return true;
				} else if (!this.getMove() && (dy == 1 || dy == 2)) {
					return true;
				} else
					return false;
			} else if ((dx == 1 || dx == -1) && dy == 1)
				return true;

			return false;
		} else if (this.getCoul() == 1) {
			if (dx == 0) {
				if (this.getMove() && dy == -1) {
					return true;
				} else if (!this.getMove() && (dy == -1 || dy == -2)) {
					return true;
				} else
					return false;
			} else if ((dx == -1 || dx == 1) && dy == -1)
				return true;

			return false;
		}
		return false;
	}
}