package projetJava;

/**
 * Gestion du Plateau de Jeu : cette classe contient des méthodes permettant la
 * gestion du plateau. Le constructeur initialise une plateau de jeu d'échec
 * tradionnelle. Cette classe contient les différentes méthodes pour : les
 * déplacements des différentes pièces sur le plateau, l'affichage du plateau et
 * la vérification si on est en échec et en échec et mat
 * 
 * @author BOUTON Nicolas et DEDARALLY Taariq
 * 
 */

public class Plateau {
	/** Plateau du jeu représenté par des cases */
	private Case[][] plateau;

	/**
	 * Initialisation du plateau de jeu : placement des pièces selon le modèle d'un
	 * jeu d'échec traditionelle
	 */
	public Plateau() {

		this.plateau = new Case[8][8];

		Case c;
		int coul = 0;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 2; j++) {
				if (j == 1) {
					c = new Case(new Pion(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 0 || i == 7) {
					c = new Case(new Tour(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 1 || i == 6) {
					c = new Case(new Cavalier(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 2 || i == 5) {
					c = new Case(new Fou(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 4) {
					c = new Case(new Roi(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 3) {
					c = new Case(new Reine(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else {
					c = new Case(null, (i + j) % 2);
					this.plateau[i][j] = c;
				}
			}
		}

		coul = 1;

		for (int i = 0; i < 8; i++) {
			for (int j = 6; j < 8; j++) {
				if (j == 6) {
					c = new Case(new Pion(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 0 || i == 7) {
					c = new Case(new Tour(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 1 || i == 6) {
					c = new Case(new Cavalier(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 2 || i == 5) {
					c = new Case(new Fou(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 4) {
					c = new Case(new Roi(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else if (i == 3) {
					c = new Case(new Reine(coul), (i + j) % 2);
					this.plateau[i][j] = c;
				} else {
					c = new Case(null, (i + j) % 2);
					this.plateau[i][j] = c;
				}
			}
		}

		for (int i = 0; i < 8; i++) {
			for (int j = 2; j < 6; j++) {
				c = new Case(null, (i + j) % 2);
				this.plateau[i][j] = c;
			}
		}

	}

	/* Partie concernant la gestion des déplacements des pièces sur le plateau */

	/**
	 * Gestion de mouvement d'un pion sur le plateau de jeu. C'est à dire le
	 * placement de la pièce pion sur le plateau. Les arguments sont un vecteur de
	 * déplacements.
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return si le déplacement est bien correcte
	 */
	public boolean movePion(int depX, int depY, int finX, int finY) {
		int dx = finX - depX;
		int dy = finY - depY;

		Case c = this.plateau[depX][depY];
		Case dest = this.plateau[finX][finY];

		boolean bouge = false;

		if (dx == 0) {
			if (this.testLigne(depX, depY, finX, finY)) {
				// Test si la case destination n'a pas de piece
				if (dest.getPiece() == null) {
					if (!c.getPiece().getMove())
						c.getPiece().changeMove();
					this.movePiece(c, dest);
					bouge = true;
				}
			}
		} else if (dx == -1 || dx == 1) {
			if (dy == -1 && c.getPiece().getCoul() == 1) {
				if (this.testDiag(depX, depY, finX, finY)) {
					if (dest.getPiece() != null && c.getPiece().getCoul() != dest.getPiece().getCoul()) {
						if (!c.getPiece().getMove())
							c.getPiece().changeMove();
						this.movePiece(c, dest);
						bouge = true;
					}
				}
			}
			if (dy == 1 && c.getPiece().getCoul() == 0) {
				if (this.testDiag(depX, depY, finX, finY)) {
					if (dest.getPiece() != null && c.getPiece().getCoul() != dest.getPiece().getCoul()) {
						if (!c.getPiece().getMove())
							c.getPiece().changeMove();
						this.movePiece(c, dest);
						bouge = true;
					}
				}
			}
		}
		if (bouge && (finY == 0 || finY == 7)) {
			IO tmp = new IO(null);
			tmp.promotion(dest);
		}

		return bouge;
	}

	/**
	 * Gestion de mouvement du cavalier sur le plateau de jeu. C'est à dire le
	 * placement de la pièce cavalier sur le plateau. Les arguments sont un vecteur
	 * de déplacements.
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return si le déplacement est bien correcte
	 */
	public boolean moveCavalier(int depX, int depY, int finX, int finY) {

		Case c = this.plateau[depX][depY];
		Case dest = this.plateau[finX][finY];

		if (dest.getPiece() == null) {
			this.movePiece(c, dest);
			return true;
		} else if (c.getPiece().getCoul() != dest.getPiece().getCoul()) {
			this.movePiece(c, dest);
			return true;
		}
		return false;
	}

	/**
	 * Gestion de déplacement d'une pièce de jeu. On vérifie si les déplacements
	 * sont possibles et on les place sur le plateau. On donne en argument le
	 * vecteur de déplacement.
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le déplacement s'est passé correctement ou faux sinon
	 */
	public boolean movePiece(int depX, int depY, int finX, int finY) {
		int dx = finX - depX;
		int dy = finY - depY;

		Case c = this.plateau[depX][depY];
		Case dest = this.plateau[finX][finY];

		// La condition test si il y a une piece, test si le mouvement de la piece est
		// bon,
		// test si toutes les coord sont dans la map, test si ce ne sont pas les même
		// coord
		if (c.getPiece() != null && c.getPiece().movePiece(depX, depY, finX, finY) && this.inMap(depX, depY, finX, finY)
				&& !(dx == 0 && dy == 0)) {
			// Traite le cas du pion
			if (c.getPiece().getClass() == Pion.class) {
				return this.movePion(depX, depY, finX, finY);
			}
			// Traite le cas du cavalier
			else if (c.getPiece().getClass() == Cavalier.class) {
				return this.moveCavalier(depX, depY, finX, finY);
			}
			// traite les autres cas
			else if (dx == 0 || dy == 0) {
				if (this.testLigne(depX, depY, finX, finY)) {
					// Test si la case destination n'a pas de piece
					if (dest.getPiece() == null) {
						this.movePiece(c, dest);
						return true;
					}
					// Test si la couleur de la piece destination est différente de la piece de
					// départ
					else if (c.getPiece().getCoul() != dest.getPiece().getCoul()) {
						this.movePiece(c, dest);
						return true;
					}
				}
			} else if (dx == dy || dx == -dy) {
				if (this.testDiag(depX, depY, finX, finY)) {
					if (dest.getPiece() == null) {
						this.movePiece(c, dest);
						return true;
					}
					// Test si la couleur de la piece destination est différente de la piece de
					// départ
					else if (c.getPiece().getCoul() != dest.getPiece().getCoul()) {
						this.movePiece(c, dest);
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Méthode de vérifications : si les coordonnées vectorielles sont bien dans le
	 * plateau de jeu.
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le vecteur et bien inclue dans le plateau de jeu ou faux
	 *         sinon
	 */
	public boolean inMap(int depX, int depY, int finX, int finY) {
		if (depX >= 0 && depX < 8 && finX >= 0 && finX < 8 && depY >= 0 && depY < 8 && finY >= 0 && finY < 8) {
			return true;
		}
		return false;
	}

	/**
	 * Test si on peut déplacer le vecteur de manière diagonal, utilisé pour les
	 * déplacements du fou et de la reine
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le déplacement est possible ou faux sinon
	 */
	public boolean testDiag(int depX, int depY, int finX, int finY) {
		int dx = finX - depX;
		int dy = finY - depY;

		// > Test diagonale
		if (dx == dy) {
			if (dx > 0) {
				return this.testDiagHautDroite(depX, depY, finX, finY);
			} else {
				return this.testDiagBasGauche(depX, depY, finX, finY);
			}
		}
		// > Test diagonale
		else if (dx == -dy) {
			if (dx > 0) {
				return this.testDiagBasDroite(depX, depY, finX, finY);
			} else {
				return this.testDiagHautGauche(depX, depY, finX, finY);
			}
		}
		return false;
	}

	/**
	 * Test la diagonale haut-droite
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testDiagHautDroite(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depX + 1, j = depY + 1; i < finX && j < finY; i++, j++) {
			c = this.plateau[i][j];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test la diagonale bas-gauche
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testDiagBasGauche(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depX - 1, j = depY - 1; i > finX && j > finY; i--, j--) {
			c = this.plateau[i][j];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test la diagonale haut-gauche
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testDiagHautGauche(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depX - 1, j = depY + 1; i > finX && j < finY; i--, j++) {
			c = this.plateau[i][j];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test la diagonale bas-droite
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testDiagBasDroite(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depX + 1, j = depY - 1; i < finX && j > finY; i++, j--) {
			c = this.plateau[i][j];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test si les déplacements en ligne sont correctes, utilisé pour la classe Tour
	 * et Reine
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testLigne(int depX, int depY, int finX, int finY) {
		int dx = finX - depX;
		int dy = finY - depY;

		// Test Verticale
		if (dx == 0) {
			if (dy > 0) {
				return this.testVerticaleLigneHaut(depX, depY, finX, finY);
			} else {
				return this.testVerticaleLigneBas(depX, depY, finX, finY);
			}
		}

		// Test Horizontale
		if (dy == 0) {
			if (dx > 0) {
				return this.testHorizontaleLigneDroite(depX, depY, finX, finY);
			} else {
				return this.testHorizontaleLigneGauche(depX, depY, finX, finY);
			}
		}
		return false;
	}

	/**
	 * Test la ligne vertical haut
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testVerticaleLigneHaut(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depY + 1; i < finY; i++) {
			c = this.plateau[depX][i];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test la ligne vertical bas
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testVerticaleLigneBas(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depY - 1; i > finY; i--) {
			c = this.plateau[depX][i];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test la ligne horizontal droite
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible ou faux sinon
	 */
	public boolean testHorizontaleLigneDroite(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depX + 1; i < finX; i++) {
			c = this.plateau[i][depY];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Test la ligne horizontal gauche
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si possible pu faux sinon
	 */
	public boolean testHorizontaleLigneGauche(int depX, int depY, int finX, int finY) {
		Case c;
		for (int i = depX - 1; i > finX; i--) {
			c = this.plateau[i][depY];
			if (c.getPiece() != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Affichage du plateau sous forme ascii sur le terminal
	 * 
	 * @param tours le nombre de tours
	 */
	public void afficher(int tours) {
		System.out.println("\nTours " + tours + " :\n");
		for (int j = 7; j >= 0; j--) {
			for (int i = 0; i < 8; i++) {
				if (i == 0) {
					System.out.print(j + 1 + " ");
				}
				if (this.plateau[i][j].getPiece() != null)
					System.out.print("[" + this.plateau[i][j].getPiece() + "]");
				else
					System.out.print("[  ]");
			}
			System.out.println(" ");
		}
		System.out.print("   a   b   c   d   e   f   g   h");
		System.out.println(" ");
	}

	/**
	 * Récupère une pièce du jeu selon les coordonnées données en entrée
	 * 
	 * @param x l'abscisse de la pièce
	 * @param y m'ordonnée de la pièce
	 * @return la pièce de la case
	 */
	public Piece getPiece(int x, int y) {
		return this.plateau[x][y].getPiece();
	}

	/**
	 * Récupère une case du jeu selon les coordonnées données en entrée
	 * 
	 * @param x l'abscisse de la pièce
	 * @param y m'ordonnée de la pièce
	 * @return la case de la pièce
	 */
	public Case getCase(int x, int y) {
		return this.plateau[x][y];
	}

	/**
	 * Effectue les switch de case donnée en argument
	 * 
	 * @param c    la case de départ
	 * @param dest la case de destination
	 */
	public void movePiece(Case c, Case dest) {
		dest.changePiece(c.getPiece());
		c.changePiece(null);
	}

	/*
	 * Partie sur l'analyse du plateau pour savoir si il y a une situation d'échec
	 */

	/**
	 * Vérifie si on est en échec
	 * 
	 * @param couleur la couleur de l'équipe du joueur en échec
	 * @return vrai si échec
	 */
	public boolean isEchec(int couleur) {
		Point point = new Point(this.findKing(couleur).getX(), this.findKing(couleur).getY());

		return checkMove_isEchec(point, couleur);
	}

	/**
	 * Vérifie si l'emplacement du point donnée en argument est un échec. Cette
	 * fonction est utilisée pour vérifier si on est en échec et en échec et mat
	 * (voir section Jeu pour en savoir plus sur l'implémentation)
	 * 
	 * @param point   Ou se situe la case ou l'on souhaite vérifier si cette case
	 *                est en situation d'échec
	 * @param couleur l'équipe
	 * @return vrai si la case est en échec
	 */
	public boolean checkMove_isEchec(Point point, int couleur) {

		// <*> Si le point qu'on souhaite vérifié est déjà dans la map ou le roi est en
		// dehors de map <*> //

		if (!(this.inMap(point.getX(), point.getY(), point.getX(), point.getY()))) {
			return true;
		}
		if (plateau[point.getX()][point.getY()].getPiece() != null) {
			if (!(plateau[point.getX()][point.getY()].getPiece().toString().equals("R" + couleur))) {
				return true;
			}
		}

		return this.havePion(point, couleur ^ 1) || this.haveCavalier(point, couleur ^ 1)
				|| this.haveDiagonal(point, couleur ^ 1) || this.haveHV(point, couleur ^ 1);
	}

	/**
	 * Recherche le roi dans sur le plateau
	 * 
	 * @param couleur la couleur de l'équipe auquel appartient le roi
	 * @return l'emplacement du roi sur le plateau
	 */
	public Point findKing(int couleur) {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (this.plateau[i][j].getPiece() != null) {
					if (this.plateau[i][j].getPiece().toString().equals("R" + couleur)) {
						return new Point(i, j);
					}
				}
			}
		}
		System.out.println("King no found :/");
		return new Point(-1, -1); // Afficher erreurs roi non trouvé
	}

	/**
	 * Recherche s'il y a une tour ou une reine adverse sur les axes horizontal
	 * vertical
	 * 
	 * @param point   la position
	 * @param couleur la couleur
	 * @return vrai s'il y a une reine ou une tour, ou faux sinon
	 */
	public boolean haveHV(final Point point, int couleur) {

		for (int x = point.getX(); x < 8; x++) {
			if (this.plateau[x][point.getY()].getPiece() != null) {

				if (this.plateau[x][point.getY()].getPiece().toString().equals("T" + couleur)
						|| this.plateau[x][point.getY()].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[x][point.getY()].getPiece().getCoul() != couleur && x != point.getX()) {
					break;
				}
			}
		}
		for (int x = point.getX(); x > 0; x--) {
			if (this.plateau[x][point.getY()].getPiece() != null) {
				if (this.plateau[x][point.getY()].getPiece().toString().equals("T" + couleur)
						|| this.plateau[x][point.getY()].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[x][point.getY()].getPiece().getCoul() != couleur && x != point.getX()) {
					break;
				}
			}
		}
		for (int y = point.getY(); y < 8; y++) {
			if (this.plateau[point.getX()][y].getPiece() != null) {
				if (this.plateau[point.getX()][y].getPiece().toString().equals("T" + couleur)
						|| this.plateau[point.getX()][y].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[point.getX()][y].getPiece().getCoul() != couleur && y != point.getY()) {
					break;
				}
			}
		}
		for (int y = point.getY(); y > 0; y--) {
			if (this.plateau[point.getX()][y].getPiece() != null) {
				if (this.plateau[point.getX()][y].getPiece().toString().equals("T" + couleur)
						|| this.plateau[point.getX()][y].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[point.getX()][y].getPiece().getCoul() != couleur && y != point.getY()) {
					break;
				}
			}
		}
		return false;
	}

	/**
	 * Recherche s'il y un fou ou une reine adverse sur les axes de diagonales
	 * 
	 * @param point   la position
	 * @param couleur la couleur
	 * @return vrai s'il y a un fou ou une reine, ou faux sinon
	 */
	public boolean haveDiagonal(final Point point, int couleur) {

		for (int x = point.getX(), y = point.getY(); x < 8 && y < 8; x++, y++) {
			if (this.plateau[x][y].getPiece() != null) {
				if (this.plateau[x][y].getPiece().toString().equals("F" + couleur)
						|| this.plateau[x][y].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[x][y].getPiece().getCoul() != couleur && (x != point.getX() && y != point.getY())) {
					break;
				}
			}
		}
		for (int x = point.getX(), y = point.getY(); x > 0 && y < 8; x--, y++) {
			if (this.plateau[x][y].getPiece() != null) {
				if (this.plateau[x][y].getPiece().toString().equals("F" + couleur)
						|| this.plateau[x][y].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[x][y].getPiece().getCoul() != couleur && (x != point.getX() && y != point.getY())) {
					break;
				}
			}
		}

		for (int x = point.getX(), y = point.getY(); x < 8 && y > 0; x++, y--) {
			if (this.plateau[x][y].getPiece() != null) {
				if (this.plateau[x][y].getPiece().toString().equals("F" + couleur)
						|| this.plateau[x][y].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[x][y].getPiece().getCoul() != couleur && (x != point.getX() && y != point.getY())) {
					break;
				}
			}
		}
		for (int x = point.getX(), y = point.getY(); x > 0 && y > 0; x--, y--) {
			if (this.plateau[x][y].getPiece() != null) {
				if (this.plateau[x][y].getPiece().toString().equals("F" + couleur)
						|| this.plateau[x][y].getPiece().toString().equals("D" + couleur)) {
					return true;
				}
				if (this.plateau[x][y].getPiece().getCoul() != couleur && (x != point.getX() && y != point.getY())) {
					break;
				}
			}
		}
		return false;
	}

	/**
	 * Recherche s'il y a un pion qui met en échec le roi
	 * 
	 * @param point   la position
	 * @param couleur la couleur
	 * @return vrai s'il y a un pion ou faux sinon
	 */
	public boolean havePion(final Point point, int couleur) {
		if (this.inMap(point.getX(), point.getY(), point.getX() + 1, point.getY() + 1)) {
			if (this.plateau[point.getX() + 1][point.getY() + 1].getPiece() != null) {
				if (this.plateau[point.getX() + 1][point.getY() + 1].getPiece().toString().equals("P" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() - 1, point.getY() + 1)) {
			if (this.plateau[point.getX() - 1][point.getY() + 1].getPiece() != null) {
				if (this.plateau[point.getX() - 1][point.getY() + 1].getPiece().toString().equals("P" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() + 1, point.getY() - 1)) {
			if (this.plateau[point.getX() + 1][point.getY() - 1].getPiece() != null) {
				if (this.plateau[point.getX() + 1][point.getY() - 1].getPiece().toString().equals("P" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() - 1, point.getY() - 1)) {
			if (this.plateau[point.getX() - 1][point.getY() - 1].getPiece() != null) {
				if (this.plateau[point.getX() - 1][point.getY() - 1].getPiece().toString().equals("P" + couleur)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Recherche s'il y a un cavalier qui met en situation d'échec la case
	 * 
	 * @param point   la position
	 * @param couleur la couleur
	 * @return vrai s'il y a un cavalier ou faux sinon
	 */
	public boolean haveCavalier(Point point, int couleur) {
		if (this.inMap(point.getX(), point.getY(), point.getX() + 1, point.getY() + 2)) {
			if (this.plateau[point.getX() + 1][point.getY() + 2].getPiece() != null) {
				if (this.plateau[point.getX() + 1][point.getY() + 2].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() - 1, point.getY() + 2)) {
			if (this.plateau[point.getX() - 1][point.getY() + 2].getPiece() != null) {
				if (this.plateau[point.getX() - 1][point.getY() + 2].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() + 2, point.getY() + 1)) {
			if (this.plateau[point.getX() + 2][point.getY() + 1].getPiece() != null) {
				if (this.plateau[point.getX() + 2][point.getY() + 1].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() - 2, point.getY() + 1)) {
			if (this.plateau[point.getX() - 2][point.getY() + 1].getPiece() != null) {
				if (this.plateau[point.getX() - 2][point.getY() + 1].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() + 2, point.getY() - 1)) {
			if (this.plateau[point.getX() + 2][point.getY() - 1].getPiece() != null) {
				if (this.plateau[point.getX() + 2][point.getY() - 1].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() - 2, point.getY() - 1)) {
			if (this.plateau[point.getX() - 2][point.getY() - 1].getPiece() != null) {
				if (this.plateau[point.getX() - 2][point.getY() - 1].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() + 1, point.getY() - 2)) {
			if (this.plateau[point.getX() + 1][point.getY() - 2].getPiece() != null) {
				if (this.plateau[point.getX() + 1][point.getY() - 2].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}

		if (this.inMap(point.getX(), point.getY(), point.getX() - 1, point.getY() - 2)) {
			if (this.plateau[point.getX() - 1][point.getY() - 2].getPiece() != null) {
				if (this.plateau[point.getX() - 1][point.getY() - 2].getPiece().toString().equals("C" + couleur)) {
					return true;
				}
			}
		}
		return false;
	}

}