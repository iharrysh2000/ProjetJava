package projetJava;

/**
 * Classe Roi : gestion de la pièce roi
 * 
 * @author BOUTON Nicolas
 */
public class Roi extends Piece {

	private final String nom = "R";

	/**
	 * Constructeur du roi
	 * 
	 * @param couleur la couleur du roi
	 */
	public Roi(int couleur) {
		super(couleur);
	}

	/**
	 * Retourne la chaine de caractères composé du nom et de la couleur du roi
	 * 
	 * @return le nom et la couleur du roi
	 */
	@Override
	public String toString() {
		return this.nom + this.getCoul();
	}

	/**
	 * Déplacement du roi
	 * 
	 * @return vrai si le déplacement est valide ou faux sinon
	 */
	@Override
	public boolean movePiece(int depX, int depY, int finX, int finY) {
		int dx = depX - finX;
		int dy = depY - finY;

		if (dx >= -1 && dx <= 1 && dy >= -1 && dy <= 1) {
			return true;
		}

		return false;
	}
}