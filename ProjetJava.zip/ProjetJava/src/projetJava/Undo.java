package projetJava;

import java.util.Stack;

/**
 * Classe Gestionnaire de pile. Cette classe permet la gestion des piles afin de
 * sauvegarder les coups fait par les joueurs. Elle contient 3 piles : 1. Pour
 * sauvegarder les coordonnées initiale de pièce avant de changer de coordonnées
 * 2. Pour sauvegarder les coordonnées après déplacements de la pièce 3. Pour
 * sauvegarder les pièces qui ont été supprimé de départ 4. Pour sauvegarder les
 * pièces qui ont été supprimé de départ
 * 
 * @author BOUTON Nicolas et DEDARALLY Taariq
 *
 */
class Undo {

	/** Pile qui sauvegarde les coordonnées de départ */
	private Stack<Point> pile_depart;

	/** Pile qui sauvegarde les coordonnées cible */
	private Stack<Point> pile_cible;

	/** Pile qui sauvegarde les pièce qui ont été supprimé de départ */
	private Stack<Piece> pile_piece_depart;

	/** Pile qui sauvegarde les pièce qui ont été supprimé cible */
	private Stack<Piece> pile_piece_cible;

	/**
	 * Constructeur de la classe Undo qui initialise des piles vides
	 */
	public Undo() {
		this.pile_depart = new Stack<Point>();
		this.pile_cible = new Stack<Point>();
		this.pile_piece_depart = new Stack<Piece>();
		this.pile_piece_cible = new Stack<Piece>();
	}

	/**
	 * Permet l'enregistrement des coordonnées
	 * 
	 * @param point_depart le point de départ
	 * @param point_cible  le point cible
	 */
	public void enregistrer_coords(Point point_depart, Point point_cible) {
		this.pile_depart.push(point_depart);
		this.pile_cible.push(point_cible);
	}

	/**
	 * Permet d'enregistrer une pièce de départ
	 * 
	 * @param piece la pièce
	 */
	public void enregistrer_piece_depart(Piece piece) {
		this.pile_piece_depart.push(piece);
	}

	/**
	 * Permet d'enregistrer une pièce cible
	 * 
	 * @param piece la pièce
	 */
	public void enregistrer_piece_cible(Piece piece) {
		this.pile_piece_cible.push(piece);
	}

	/**
	 * Permet d'enregistrer les pièces de départ et cible
	 * 
	 * @param piece_depart la pièce de départ
	 * @param piece_cible  la pièce cible
	 */
	public void enregistrer_piece(Piece piece_depart, Piece piece_cible) {
		this.pile_piece_depart.push(piece_depart);
		this.pile_piece_cible.push(piece_cible);
	}

	/**
	 * Dépile les coordonnées de départ
	 * 
	 * @return coordonnées de départ
	 */
	public Point depile_point_depart() {
		if (!this.pile_depart.empty()) {
			return this.pile_depart.pop();
		}
		return null;
	}

	/**
	 * Dépile les coordonnées cible
	 * 
	 * @return les coordonnées cible
	 */
	public Point depile_point_cible() {
		if (!this.pile_cible.empty()) {
			return this.pile_cible.pop();
		}
		return null;
	}

	/**
	 * Dépile les pièces qui ont été supprimé durant la partie
	 * 
	 * @return piece la pièce
	 */
	public Piece depile_piece_depart() {
		if (!this.pile_piece_depart.empty()) {
			return this.pile_piece_depart.pop();
		}
		return null;
	}

	/**
	 * Dépile les pièces qui ont été supprimé durant la partie
	 * 
	 * @return piece la pièce
	 */
	public Piece depile_piece_cible() {
		if (!this.pile_piece_cible.empty()) {
			return this.pile_piece_cible.pop();
		}
		return null;
	}

	/**
	 * Getteur de la pile de coordonnées de départ
	 * 
	 * @return pile la pile
	 */
	public Stack<Point> getPile_point_depart() {
		return this.pile_depart;
	}

	/**
	 * Getteur de la pile de coordonnées cible
	 * 
	 * @return pile la pile
	 */
	public Stack<Point> getPile_point_cible() {
		return this.pile_cible;
	}

	/**
	 * Getteur de la pile des pièces
	 * 
	 * @return pile la pile
	 */
	public Stack<Piece> getPile_piece_depart() {
		return this.pile_piece_depart;
	}

	/**
	 * Getteur de la pile des pièces
	 * 
	 * @return pile la pile
	 */
	public Stack<Piece> getPile_piece_cible() {
		return this.pile_piece_cible;
	}
}