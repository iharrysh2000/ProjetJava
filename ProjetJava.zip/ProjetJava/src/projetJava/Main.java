package projetJava;

/**
 * Représente l'application
 * 
 * @version mai. 2017
 * @author BOUTON Nicolas et DEDARALLY Taariq et TRINH Gia Tâm
 * 
 */
public class Main {

	/**
	 * Programme principal
	 * 
	 * @param args on ne s'en sert pas
	 */
	public static void main(String[] args) {

		Jeu jeu = new Jeu();

		jeu.jouer();
	}

}