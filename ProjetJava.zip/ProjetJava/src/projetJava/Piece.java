package projetJava;

/**
 * Classe Pièce : représente de manière abstraite une pièce
 * 
 * @author BOUTON Nicolas
 */
public abstract class Piece {
	private int couleur;
	private boolean move;

	/**
	 * Constructeur de la classe pièce
	 * 
	 * @param couleur la couleur de la pièce
	 */
	public Piece(int couleur) {
		this.couleur = couleur;
		this.move = false;
	}

	/**
	 * Getteur de la nature du mouvement de la pièce
	 * 
	 * @return la nature du mouvement
	 */
	public boolean getMove() {
		return this.move;
	}

	/**
	 * Modifie la nature du mouvement de la pièce
	 */
	public void changeMove() {
		this.move = true;
	}

	/**
	 * Getteur de la couleur de la pièce
	 * 
	 * @return la couleur de la pièce
	 */
	public int getCoul() {
		return this.couleur;
	}

	/**
	 * Déplacement d'une pièce
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le mouvement est possible et faux sinon
	 */
	public abstract boolean movePiece(int depX, int depY, int finX, int finY);
}