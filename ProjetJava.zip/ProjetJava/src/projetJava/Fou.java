package projetJava;

/**
 * Classe Fou : gestion de la pièce fou
 * 
 * @author BOUTON Nicolas
 */
public class Fou extends Piece {

	private final String nom = "F";

	/**
	 * Constructeur du fou
	 * 
	 * @param couleur la couleur du fou
	 */
	public Fou(int couleur) {
		super(couleur);
	}

	/**
	 * Renvoie la chaine de caractères composée du nom et de la couleur du fou
	 * 
	 * @return le nom et la couleur du fou
	 */
	@Override
	public String toString() {
		return this.nom + this.getCoul();
	}

	/**
	 * Déplacement du fou
	 * 
	 * @param depX l'abscisse de départ
	 * @param depY l'ordonnée de départ
	 * @param finX l'abscisse d'arrivée
	 * @param finY l'ordonnée d'arrivée
	 * @return vrai si le déplacement est valide ou faux sinon
	 */
	@Override
	public boolean movePiece(int depX, int depY, int finX, int finY) {
		int dx = depX - finX;
		int dy = depY - finY;

		if ((dx == dy) || (dx == -dy)) {
			return true;
		}

		return false;
	}
}